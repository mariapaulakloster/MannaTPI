import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ElementCard = ({ symbol, name, atomicNumber, atomicMass, reaction }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.atomicNumber}>{atomicNumber}</Text>
      <Text style={styles.symbol}>{symbol}</Text>
      <Text style={styles.name}>{name}</Text>
      <Text style={styles.atomicMass}>{atomicMass}</Text>
      <Text style={styles.reaction}>{reaction}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  atomicNumber: {
    fontSize: 15,
    fontWeight: 'italic',
    marginBottom: 5,
  },
  symbol: {
    fontSize: 50,
    fontWeight: 'bold',
    textAlign: 'center',
  },
    name: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  atomicMass: {
    fontSize: 15,
    fontStyle: 'italic',
    marginTop: 5,
  },
  reaction: {
    fontSize: 15,
    fontStyle: 'italic',
    marginTop: 10,
  }
});

export default ElementCard;